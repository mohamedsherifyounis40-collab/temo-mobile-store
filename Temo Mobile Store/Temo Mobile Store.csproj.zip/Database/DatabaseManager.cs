﻿using Microsoft.Data.Sqlite;
using System;
using System.IO;
using System.Windows.Forms;

namespace Temo_Mobile_Store.Database
{
    public static class DatabaseManager
    {
        private static readonly string DatabasePath =
            Path.Combine(Application.StartupPath, "TemoStoreDB.db");

        private static readonly string ConnectionString =
            $"Data Source={DatabasePath}";

        public static SqliteConnection GetConnection()
        {
            return new SqliteConnection(ConnectionString);
        }
    }
}