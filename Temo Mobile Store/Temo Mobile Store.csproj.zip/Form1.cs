using System;
using System.Drawing;
using System.Data;
using Microsoft.Data.Sqlite;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace Temo_Mobile_Store
{
    public partial class Form1 : Form
    {
        private string connectionString = @"Data Source=D:\TemoStoreDB.db;";

        // أدوات المخزن
        private TextBox txtBarcode, txtProductName, txtCostPrice, txtSalePrice, txtQuantity;
        private Button btnAddProduct, btnEditMode, btnSaveUpdate, btnDeleteProduct, btnClear;
        private DataGridView dgvProducts;

        // أدوات المبيعات (الكاشير) المحدثة 🛒
        private TextBox txtSaleBarcode, txtSaleName, txtCustomerPrice, txtSaleQty, txtSaleTotal;
        private Button btnAddToBill, btnPrintInvoice, btnReturnSale; // إضافة زر المرتجعات
        private DataGridView dgvSales;

        // أدوات شاشة التقارير والأرباح 📊
        private Label lblTotalSalesVal, lblTotalCapitalVal, lblTotalExpensesVal, lblTotalNetProfitVal;
        private DataGridView dgvReports;
        private Button btnRefreshReports, btnFilterReports;
        private DateTimePicker dtpFrom, dtpTo;

        // أدوات شاشة المصروفات والشجرة 
        private ComboBox cmbExpenseAccounts;
        private TextBox txtExpenseAmount;
        private Button btnAddExpense, btnEditExpenseMode, btnSaveExpenseUpdate, btnDeleteExpense;
        private DataGridView dgvExpenses;
        private int selectedExpenseID = -1;

        public Form1()
        {
            this.Text = "نظام إدارة تيمو ستور - إصدار إدارة المرتجعات والتواريخ الاحترافي V8";
            this.Size = new Size(1150, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;

            InitializeTabs();
            LoadProductsData();
            LoadSalesData();
            LoadAccountsTreeIntoCombo();
            LoadExpensesData();
            CalculateBusinessMetrics();
        }

        private void InitializeTabs()
        {
            TabControl tabControl = new TabControl() { Dock = DockStyle.Fill };
            TabPage tabInventory = new TabPage() { Text = "إدارة المخزن والبضاعة" };
            TabPage tabPOS = new TabPage() { Text = "شاشة المبيعات والكاشير" };
            TabPage tabReports = new TabPage() { Text = "التقارير والأرباح 📊" };
            TabPage tabExpenses = new TabPage() { Text = "إدارة المصروفات العمومية 💸" };

            tabControl.TabPages.AddRange(new TabPage[] { tabInventory, tabPOS, tabReports, tabExpenses });
            this.Controls.Add(tabControl);

            CreateInventoryDesign(tabInventory);
            CreatePOSDesign(tabPOS);
            CreateReportsDesign(tabReports);
            CreateExpensesDesign(tabExpenses);
        }

        private void CreateInventoryDesign(TabPage page)
        {
            Label lblBarcode = new Label() { Text = "باركود المنتج:", Location = new Point(20, 30), AutoSize = true };
            txtBarcode = new TextBox() { Location = new Point(130, 27), Width = 150 };

            Label lblProductName = new Label() { Text = "اسم المنتج:", Location = new Point(20, 70), AutoSize = true };
            txtProductName = new TextBox() { Location = new Point(130, 67), Width = 150 };

            Label lblCostPrice = new Label() { Text = "سعر الشراء (التكلفة):", Location = new Point(20, 110), AutoSize = true };
            txtCostPrice = new TextBox() { Location = new Point(130, 107), Width = 150 };

            Label lblSalePrice = new Label() { Text = "سعر البيع للجمهور:", Location = new Point(20, 150), AutoSize = true };
            txtSalePrice = new TextBox() { Location = new Point(130, 147), Width = 150 };

            Label lblQuantity = new Label() { Text = "الكمية:", Location = new Point(20, 190), AutoSize = true };
            txtQuantity = new TextBox() { Location = new Point(130, 187), Width = 150 };

            btnAddProduct = new Button() { Text = "إضافة منتج جديد", Location = new Point(130, 235), Width = 150, Height = 35, BackColor = Color.LightGreen };
            btnAddProduct.Click += btnAddProduct_Click;

            btnEditMode = new Button() { Text = "تعديل البند المحدّد", Location = new Point(130, 280), Width = 150, Height = 35, BackColor = Color.LightSkyBlue };
            btnEditMode.Click += btnEditMode_Click;

            btnSaveUpdate = new Button() { Text = "حفظ التعديلات 💾", Location = new Point(130, 325), Width = 150, Height = 40, BackColor = Color.Gold, Font = new Font("Segoe UI", 9, FontStyle.Bold), Enabled = false };
            btnSaveUpdate.Click += btnSaveUpdate_Click;

            btnDeleteProduct = new Button() { Text = "حذف المنتج المحدد", Location = new Point(130, 375), Width = 150, Height = 35, BackColor = Color.LightCoral };
            btnDeleteProduct.Click += btnDeleteProduct_Click;

            btnClear = new Button() { Text = "تفريغ الخانات", Location = new Point(130, 420), Width = 150, Height = 30, BackColor = Color.WhiteSmoke };
            btnClear.Click += (s, e) => ClearInputs();

            dgvProducts = new DataGridView() { Location = new Point(310, 27), Size = new Size(800, 620), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true, AllowUserToAddRows = false };
            dgvProducts.CellClick += dgvProducts_CellClick;

            page.Controls.AddRange(new Control[] { lblBarcode, txtBarcode, lblProductName, txtProductName, lblCostPrice, txtCostPrice, lblSalePrice, txtSalePrice, lblQuantity, txtQuantity, btnAddProduct, btnEditMode, btnSaveUpdate, btnDeleteProduct, btnClear, dgvProducts });
        }

        private void CreatePOSDesign(TabPage page)
        {
            Label lblBarcode = new Label() { Text = "مسح الباركود (Enter):", Location = new Point(20, 30), AutoSize = true };
            txtSaleBarcode = new TextBox() { Location = new Point(130, 27), Width = 150 };
            txtSaleBarcode.KeyDown += TxtSaleBarcode_KeyDown;

            Label lblName = new Label() { Text = "اسم المنتج:", Location = new Point(20, 70), AutoSize = true };
            txtSaleName = new TextBox() { Location = new Point(130, 67), Width = 150, ReadOnly = true };

            Label lblPrice = new Label() { Text = "سعر البيع:", Location = new Point(20, 110), AutoSize = true };
            txtCustomerPrice = new TextBox() { Location = new Point(130, 107), Width = 150, ReadOnly = true };

            Label lblQty = new Label() { Text = "الكمية المطلوبة:", Location = new Point(20, 150), AutoSize = true };
            txtSaleQty = new TextBox() { Location = new Point(130, 147), Width = 150, Text = "1" };
            txtSaleQty.TextChanged += TxtSaleQty_TextChanged;

            Label lblTotal = new Label() { Text = "إجمالي الحساب:", Location = new Point(20, 190), AutoSize = true };
            txtSaleTotal = new TextBox() { Location = new Point(130, 187), Width = 150, ReadOnly = true, BackColor = Color.Yellow, Font = new Font("Segoe UI", 10, FontStyle.Bold) };

            btnAddToBill = new Button() { Text = "إتمام عملية البيع 🛒", Location = new Point(130, 240), Width = 150, Height = 40, BackColor = Color.Orange };
            btnAddToBill.Click += BtnAddToBill_Click;

            btnPrintInvoice = new Button() { Text = "طباعة آخر فاتورة 🖨️", Location = new Point(130, 295), Width = 150, Height = 40, BackColor = Color.LightGray };
            btnPrintInvoice.Click += BtnPrintInvoice_Click;

            // زر المرتجعات الجديد بالكامل 🔄
            btnReturnSale = new Button() { Text = "إرجاع البند المحدد ↩️", Location = new Point(130, 350), Width = 150, Height = 40, BackColor = Color.LightCoral, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            btnReturnSale.Click += BtnReturnSale_Click;

            dgvSales = new DataGridView() { Location = new Point(310, 27), Size = new Size(800, 620), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true, AllowUserToAddRows = false };

            page.Controls.AddRange(new Control[] { lblBarcode, txtSaleBarcode, lblName, txtCustomerPrice, lblQty, txtSaleQty, lblTotal, txtSaleTotal, btnAddToBill, btnPrintInvoice, btnReturnSale, dgvSales });
        }

        private void CreateReportsDesign(TabPage page)
        {
            GroupBox gbSummary = new GroupBox() { Text = "خلاصة حركة المال والملخص المالي", Location = new Point(20, 20), Size = new Size(260, 310) };

            Label lblTotalSales = new Label() { Text = "إجمالي المبيعات (الدرج):", Location = new Point(15, 30), AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            lblTotalSalesVal = new Label() { Text = "0.00 ج.م", Location = new Point(15, 50), AutoSize = true, ForeColor = Color.Blue, Font = new Font("Segoe UI", 11, FontStyle.Bold) };

            Label lblTotalCapital = new Label() { Text = "تكلفة البضاعة المباعة:", Location = new Point(15, 95), AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            lblTotalCapitalVal = new Label() { Text = "0.00 ج.م", Location = new Point(15, 115), AutoSize = true, ForeColor = Color.DarkGreen, Font = new Font("Segoe UI", 11, FontStyle.Bold) };

            Label lblTotalExpenses = new Label() { Text = "إجمالي المصروفات العمومية:", Location = new Point(15, 160), AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            lblTotalExpensesVal = new Label() { Text = "0.00 ج.م", Location = new Point(15, 180), AutoSize = true, ForeColor = Color.DarkRed, Font = new Font("Segoe UI", 11, FontStyle.Bold) };

            Label lblTotalNetProfit = new Label() { Text = "الصافي الفعلي في جيبك 💰:", Location = new Point(15, 230), AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            lblTotalNetProfitVal = new Label() { Text = "0.00 ج.م", Location = new Point(15, 255), AutoSize = true, ForeColor = Color.Purple, Font = new Font("Segoe UI", 14, FontStyle.Bold) };

            gbSummary.Controls.AddRange(new Control[] { lblTotalSales, lblTotalSalesVal, lblTotalCapital, lblTotalCapitalVal, lblTotalExpenses, lblTotalExpensesVal, lblTotalNetProfit, lblTotalNetProfitVal });

            GroupBox gbFilter = new GroupBox() { Text = "فلترة التقارير بالفترة الزمنية", Location = new Point(20, 340), Size = new Size(260, 160) };
            Label lblFrom = new Label() { Text = "من تاريخ:", Location = new Point(10, 25), AutoSize = true };
            dtpFrom = new DateTimePicker() { Location = new Point(10, 45), Width = 230, Format = DateTimePickerFormat.Short };

            Label lblTo = new Label() { Text = "إلى تاريخ:", Location = new Point(10, 75), AutoSize = true };
            dtpTo = new DateTimePicker() { Location = new Point(10, 95), Width = 230, Format = DateTimePickerFormat.Short };

            btnFilterReports = new Button() { Text = "تطبيق الفلتر 🔍", Location = new Point(10, 125), Width = 230, Height = 30, BackColor = Color.LightGreen };
            btnFilterReports.Click += btnFilterReports_Click;
            gbFilter.Controls.AddRange(new Control[] { lblFrom, dtpFrom, lblTo, dtpTo, btnFilterReports });

            btnRefreshReports = new Button() { Text = "عرض الكل وتحديث الحسابات 🔄", Location = new Point(20, 510), Width = 260, Height = 45, BackColor = Color.LightSkyBlue, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnRefreshReports.Click += (s, e) => { CalculateBusinessMetrics(); LoadSalesData(); LoadExpensesData(); };

            Label lblTableTitle = new Label() { Text = "سجل الأرباح التفصيلي للبضاعة المباعة بتواريخها اللحظية:", Location = new Point(310, 20), AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            dgvReports = new DataGridView() { Location = new Point(310, 45), Size = new Size(800, 600), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true, AllowUserToAddRows = false };

            page.Controls.AddRange(new Control[] { gbSummary, gbFilter, btnRefreshReports, lblTableTitle, dgvReports });
        }

        private void CreateExpensesDesign(TabPage page)
        {
            GroupBox gbAddExpense = new GroupBox() { Text = "إدارة وتسجيل بند مصروفات", Location = new Point(20, 20), Size = new Size(260, 340) };

            Label lblExpAcc = new Label() { Text = "اختر بند الحساب المصروف:", Location = new Point(10, 30), AutoSize = true };
            cmbExpenseAccounts = new ComboBox() { Location = new Point(10, 55), Width = 230, DropDownStyle = ComboBoxStyle.DropDownList };

            Label lblExpAmount = new Label() { Text = "المبلغ المدفوع (ج.م):", Location = new Point(10, 105), AutoSize = true };
            txtExpenseAmount = new TextBox() { Location = new Point(10, 130), Width = 230 };

            btnAddExpense = new Button() { Text = "تسجيل مصروف جديد 💸", Location = new Point(10, 170), Width = 230, Height = 35, BackColor = Color.LightGreen, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            btnAddExpense.Click += BtnAddExpense_Click;

            btnEditExpenseMode = new Button() { Text = "تعديل البند المحدّد", Location = new Point(10, 210), Width = 230, Height = 35, BackColor = Color.LightSkyBlue };
            btnEditExpenseMode.Click += BtnEditExpenseMode_Click;

            btnSaveExpenseUpdate = new Button() { Text = "حفظ تعديل المصروف 💾", Location = new Point(10, 250), Width = 230, Height = 35, BackColor = Color.Gold, Font = new Font("Segoe UI", 9, FontStyle.Bold), Enabled = false };
            btnSaveExpenseUpdate.Click += BtnSaveExpenseUpdate_Click;

            btnDeleteExpense = new Button() { Text = "حذف بند المصروف", Location = new Point(10, 295), Width = 230, Height = 30, BackColor = Color.LightCoral };
            btnDeleteExpense.Click += BtnDeleteExpense_Click;

            gbAddExpense.Controls.AddRange(new Control[] { lblExpAcc, cmbExpenseAccounts, lblExpAmount, txtExpenseAmount, btnAddExpense, btnEditExpenseMode, btnSaveExpenseUpdate, btnDeleteExpense });

            Label lblExpTitle = new Label() { Text = "دفتر وسجل حركات المصروفات العمومية المدفوعة بالتفصيل والتواريخ الحية:", Location = new Point(310, 20), AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            dgvExpenses = new DataGridView() { Location = new Point(310, 45), Size = new Size(800, 600), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true, AllowUserToAddRows = false };
            dgvExpenses.CellClick += dgvExpenses_CellClick;

            page.Controls.AddRange(new Control[] { gbAddExpense, lblExpTitle, dgvExpenses });
        }

        // دالة وعملية الارتجاع المطور 🔄
        private void BtnReturnSale_Click(object sender, EventArgs e)
        {
            if (dgvSales.CurrentRow == null)
            {
                MessageBox.Show("من فضلك حدد حركة البيع المراد إرجاعها من الجدول أولاً!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int saleID = Convert.ToInt32(dgvSales.CurrentRow.Cells["رقم البيع"].Value);
            string productName = dgvSales.CurrentRow.Cells["المنتج"].Value.ToString();
            int qtyReturned = Convert.ToInt32(dgvSales.CurrentRow.Cells["الكمية المباعة"].Value);

            if (MessageBox.Show($"هل أنت متأكد من عمل مرتجع للبند: ({productName}) بكمية ({qtyReturned})؟\nسيتم إعادة البضاعة للمخزن وتعديل الحسابات المادية فوراً.", "تأكيد عملية المرتجع", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqliteConnection conn = new SqliteConnection(connectionString))
                {
                    try
                    {
                        conn.Open();

                        // 1. جلب باركود الحركة لإعادة زيادة المخزن بناءً عليه
                        string getBarcodeQuery = "SELECT Barcode FROM Sales WHERE SaleID = @SaleID";
                        string barcode = "";
                        using (SqliteCommand cmdGet = new SqliteCommand(getBarcodeQuery, conn))
                        {
                            cmdGet.Parameters.AddWithValue("@SaleID", saleID);
                            var res = cmdGet.ExecuteScalar();
                            if (res != null) barcode = res.ToString();
                        }

                        // 2. إعادة زيادة الكمية في جدول المخزن Products
                        if (!string.IsNullOrEmpty(barcode))
                        {
                            string returnStockQuery = "UPDATE Products SET Quantity = Quantity + @Qty WHERE Barcode = @Barcode";
                            using (SqliteCommand cmdReturnStock = new SqliteCommand(returnStockQuery, conn))
                            {
                                cmdReturnStock.Parameters.AddWithValue("@Qty", qtyReturned);
                                cmdReturnStock.Parameters.AddWithValue("@Barcode", barcode);
                                cmdReturnStock.ExecuteNonQuery();
                            }
                        }

                        // 3. حذف الحركة تماماً من جدول المبيعات Sales لضبط الدفاتر المادية
                        string deleteSaleQuery = "DELETE FROM Sales WHERE SaleID = @SaleID";
                        using (SqliteCommand cmdDelSale = new SqliteCommand(deleteSaleQuery, conn))
                        {
                            cmdDelSale.Parameters.AddWithValue("@SaleID", saleID);
                            cmdDelSale.ExecuteNonQuery();
                        }

                        MessageBox.Show("تمت عملية المرتجع بنجاح، وإرجاع البضاعة للمخزن وتحديث خلاصة الأرباح المادية!", "تم المرتجع", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // تحديث جداول وخلاصات الشاشات بالكامل
                        LoadProductsData();
                        LoadSalesData();
                        CalculateBusinessMetrics();
                        ClearPOSInputs();
                    }
                    catch (Exception ex) { MessageBox.Show("حدث خطأ أثناء المرتجع: " + ex.Message); }
                }
            }
        }

        private void btnFilterReports_Click(object sender, EventArgs e)
        {
            string fromDate = dtpFrom.Value.ToString("yyyy-MM-dd") + " 00:00:00";
            string toDate = dtpTo.Value.ToString("yyyy-MM-dd") + " 23:59:59";

            DataTable dtReports = new DataTable();
            dtReports.Columns.AddRange(new DataColumn[] {
                new DataColumn("رقم الحركة"), new DataColumn("المنتج"), new DataColumn("سعر الشراء"),
                new DataColumn("سعر البيع"), new DataColumn("الكمية"), new DataColumn("الربح الصافي"), new DataColumn("التاريخ والوقت ⏰")
            });

            string query = "SELECT SaleID, ProductName, CostPrice, Price, QuantitySold, Total, SaleDate FROM Sales WHERE SaleDate BETWEEN @From AND @To ORDER BY SaleID DESC";

            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@From", fromDate);
                    cmd.Parameters.AddWithValue("@To", toDate);
                    try
                    {
                        conn.Open();
                        decimal totalSales = 0, totalCost = 0;
                        using (SqliteDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                decimal cost = Convert.ToDecimal(reader["CostPrice"]);
                                decimal sell = Convert.ToDecimal(reader["Price"]);
                                int qty = Convert.ToInt32(reader["QuantitySold"]);
                                decimal total = Convert.ToDecimal(reader["Total"]);

                                totalSales += total;
                                totalCost += (cost * qty);

                                dtReports.Rows.Add(reader["SaleID"], reader["ProductName"], cost, sell, qty, (sell - cost) * qty, reader["SaleDate"]);
                            }
                        }
                        dgvReports.DataSource = dtReports;

                        decimal totalExpenses = 0;
                        string expQuery = "SELECT SUM(Amount) FROM Expenses WHERE ExpenseDate BETWEEN @From AND @To";
                        using (SqliteCommand cmdExp = new SqliteCommand(expQuery, conn))
                        {
                            cmdExp.Parameters.AddWithValue("@From", fromDate);
                            cmdExp.Parameters.AddWithValue("@To", toDate);
                            var res = cmdExp.ExecuteScalar();
                            totalExpenses = res != DBNull.Value ? Convert.ToDecimal(res) : 0;
                        }

                        decimal netProfit = (totalSales - totalCost) - totalExpenses;

                        lblTotalSalesVal.Text = totalSales.ToString("N2") + " ج.م";
                        lblTotalCapitalVal.Text = totalCost.ToString("N2") + " ج.م";
                        lblTotalExpensesVal.Text = totalExpenses.ToString("N2") + " ج.م";
                        lblTotalNetProfitVal.Text = netProfit.ToString("N2") + " ج.م";
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void LoadAccountsTreeIntoCombo()
        {
            DataTable dt = new DataTable();
            string query = "SELECT AccountCode, AccountName FROM AccountsTree";
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        dt.Load(cmd.ExecuteReader());
                        cmbExpenseAccounts.DataSource = dt;
                        cmbExpenseAccounts.DisplayMember = "AccountName";
                        cmbExpenseAccounts.ValueMember = "AccountCode";
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void BtnAddExpense_Click(object sender, EventArgs e)
        {
            if (cmbExpenseAccounts.SelectedValue == null || !decimal.TryParse(txtExpenseAmount.Text, out decimal amount))
            {
                MessageBox.Show("من فضلك اختر الحساب واكتب المبلغ بشكل صحيح!", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedCode = Convert.ToInt32(cmbExpenseAccounts.SelectedValue);
            string query = "INSERT INTO Expenses (AccountCode, Amount) VALUES (@AccountCode, @Amount)";
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AccountCode", selectedCode);
                    cmd.Parameters.AddWithValue("@Amount", amount);
                    try
                    {
                        conn.Open(); cmd.ExecuteNonQuery();
                        ClearExpenseInputs();
                        LoadExpensesData();
                        CalculateBusinessMetrics();
                        MessageBox.Show("تم تسجيل المصروف بنجاح بالتاريخ والوقت اللحظي!", "تم التسجيل", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void dgvExpenses_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvExpenses.Rows[e.RowIndex];
                selectedExpenseID = Convert.ToInt32(row.Cells["رقم الحركة"].Value);
                cmbExpenseAccounts.SelectedValue = Convert.ToInt32(row.Cells["كود الحساب"].Value);
                txtExpenseAmount.Text = row.Cells["المبلغ ج.م"].Value.ToString();
                btnSaveExpenseUpdate.Enabled = false;
            }
        }

        private void BtnEditExpenseMode_Click(object sender, EventArgs e)
        {
            if (selectedExpenseID == -1)
            {
                MessageBox.Show("من فضلك اختر حركة مصروف من الجدول أولاً لتعديلها!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            btnSaveExpenseUpdate.Enabled = true;
        }

        private void BtnSaveExpenseUpdate_Click(object sender, EventArgs e)
        {
            if (selectedExpenseID == -1 || !decimal.TryParse(txtExpenseAmount.Text, out decimal amount)) return;

            int selectedCode = Convert.ToInt32(cmbExpenseAccounts.SelectedValue);
            string query = "UPDATE Expenses SET AccountCode = @AccountCode, Amount = @Amount WHERE ExpenseID = @ExpenseID";
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AccountCode", selectedCode);
                    cmd.Parameters.AddWithValue("@Amount", amount);
                    cmd.Parameters.AddWithValue("@ExpenseID", selectedExpenseID);
                    try
                    {
                        conn.Open(); cmd.ExecuteNonQuery();
                        btnSaveExpenseUpdate.Enabled = false;
                        ClearExpenseInputs();
                        LoadExpensesData();
                        CalculateBusinessMetrics();
                        MessageBox.Show("تم تعديل قيمة المصروف وتحديث الخلاصة المالية بنجاح!", "تم التعديل", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void BtnDeleteExpense_Click(object sender, EventArgs e)
        {
            if (selectedExpenseID == -1) return;
            if (MessageBox.Show("هل أنت متأكد من حذف حركة المصروف هذه نهائياً؟", "تأكيد الحذف", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                string query = "DELETE FROM Expenses WHERE ExpenseID = @ExpenseID";
                using (SqliteConnection conn = new SqliteConnection(connectionString))
                {
                    using (SqliteCommand cmd = new SqliteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ExpenseID", selectedExpenseID);
                        try
                        {
                            conn.Open(); cmd.ExecuteNonQuery();
                            ClearExpenseInputs();
                            LoadExpensesData();
                            CalculateBusinessMetrics();
                            MessageBox.Show("تم حذف حركة المصروف بنجاح!", "تم الحذف", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex) { MessageBox.Show(ex.Message); }
                    }
                }
            }
        }

        private void ClearExpenseInputs()
        {
            selectedExpenseID = -1;
            txtExpenseAmount.Clear();
            btnSaveExpenseUpdate.Enabled = false;
        }

        private void LoadExpensesData()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[] {
                new DataColumn("رقم الحركة"),
                new DataColumn("كود الحساب"),
                new DataColumn("اسم بند المصروف"),
                new DataColumn("المبلغ ج.م"),
                new DataColumn("التاريخ والوقت ⏰")
            });

            string query = @"SELECT E.ExpenseID, E.AccountCode, A.AccountName, E.Amount, E.ExpenseDate 
                             FROM Expenses E 
                             INNER JOIN AccountsTree A ON E.AccountCode = A.AccountCode 
                             ORDER BY E.ExpenseID DESC";

            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqliteDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                dt.Rows.Add(reader["ExpenseID"], reader["AccountCode"], reader["AccountName"], reader["Amount"], reader["ExpenseDate"]);
                        }
                        dgvExpenses.DataSource = dt;
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void CalculateBusinessMetrics()
        {
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    decimal totalSales = 0, totalCost = 0;
                    string salesQuery = "SELECT SUM(Total) as TotalSales, SUM(CostPrice * QuantitySold) as TotalCost FROM Sales";
                    using (SqliteCommand cmd = new SqliteCommand(salesQuery, conn))
                    {
                        using (SqliteDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                totalSales = reader["TotalSales"] != DBNull.Value ? Convert.ToDecimal(reader["TotalSales"]) : 0;
                                totalCost = reader["TotalCost"] != DBNull.Value ? Convert.ToDecimal(reader["TotalCost"]) : 0;
                            }
                        }
                    }

                    decimal totalExpenses = 0;
                    string expenseQuery = "SELECT SUM(Amount) FROM Expenses";
                    using (SqliteCommand cmdExp = new SqliteCommand(expenseQuery, conn))
                    {
                        var res = cmdExp.ExecuteScalar();
                        totalExpenses = res != DBNull.Value ? Convert.ToDecimal(res) : 0;
                    }

                    decimal netProfit = (totalSales - totalCost) - totalExpenses;

                    lblTotalSalesVal.Text = totalSales.ToString("N2") + " ج.م";
                    lblTotalCapitalVal.Text = totalCost.ToString("N2") + " ج.م";
                    lblTotalExpensesVal.Text = totalExpenses.ToString("N2") + " ج.م";
                    lblTotalNetProfitVal.Text = netProfit.ToString("N2") + " ج.م";
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        }

        private void TxtSaleBarcode_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("دخلت هنا");

            if (e.KeyCode == Keys.Enter && !string.IsNullOrEmpty(txtSaleBarcode.Text))
            {
                string query = "SELECT ProductName, SalePrice, Quantity FROM Products WHERE Barcode = @Barcode";
                using (SqliteConnection conn = new SqliteConnection(connectionString))
                {
                    using (SqliteCommand cmd = new SqliteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Barcode", txtSaleBarcode.Text);
                        try
                        {
                            conn.Open();
                            using (SqliteDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    int stockQty = Convert.ToInt32(reader["Quantity"]);
                                    if (stockQty <= 0)
                                    {
                                        MessageBox.Show("عذراً، هذا المنتج نفذ من المخزن تماماً!", "نفذت الكمية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        return;
                                    }
                                    txtSaleName.Text = reader["ProductName"].ToString();
                                    txtCustomerPrice.Text = reader["SalePrice"].ToString();
                                    CalculateTotal();
                                    txtSaleQty.Focus();
                                }
                                else { MessageBox.Show("هذا الباركود غير مسجل في المخزن!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                            }
                        }
                        catch (Exception ex) { MessageBox.Show(ex.Message); }
                    }
                }
            }
        }

        private void TxtSaleQty_TextChanged(object sender, EventArgs e) { CalculateTotal(); }

        private void CalculateTotal()
        {
            if (decimal.TryParse(txtCustomerPrice.Text, out decimal price) && int.TryParse(txtSaleQty.Text, out int qty))
                txtSaleTotal.Text = (price * qty).ToString();
        }

        private void BtnAddToBill_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSaleName.Text) || !int.TryParse(txtSaleQty.Text, out int qtySold)) return;

            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string checkQuery = "SELECT Quantity, Price FROM Products WHERE Barcode = @Barcode";
                    int currentStock = 0; decimal currentCostPrice = 0;
                    using (SqliteCommand cmdCheck = new SqliteCommand(checkQuery, conn))
                    {
                        cmdCheck.Parameters.AddWithValue("@Barcode", txtSaleBarcode.Text);
                        using (SqliteDataReader reader = cmdCheck.ExecuteReader())
                        {
                            if (reader.Read()) { currentStock = Convert.ToInt32(reader["Quantity"]); currentCostPrice = Convert.ToDecimal(reader["Price"]); }
                        }
                    }

                    if (qtySold > currentStock)
                    {
                        MessageBox.Show($"الكمية المطلوبة أكبر من المتاح! المتاح حالياً هو: {currentStock}", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    string insertSale = "INSERT INTO Sales (Barcode, ProductName, CostPrice, Price, QuantitySold, Total) VALUES (@Barcode, @ProductName, @CostPrice, @Price, @QuantitySold, @Total)";
                    using (SqliteCommand cmdInsert = new SqliteCommand(insertSale, conn))
                    {
                        cmdInsert.Parameters.AddWithValue("@Barcode", txtSaleBarcode.Text);
                        cmdInsert.Parameters.AddWithValue("@ProductName", txtSaleName.Text);
                        cmdInsert.Parameters.AddWithValue("@CostPrice", currentCostPrice);
                        cmdInsert.Parameters.AddWithValue("@Price", Convert.ToDecimal(txtCustomerPrice.Text));
                        cmdInsert.Parameters.AddWithValue("@QuantitySold", qtySold);
                        cmdInsert.Parameters.AddWithValue("@Total", Convert.ToDecimal(txtSaleTotal.Text));
                        cmdInsert.ExecuteNonQuery();
                    }

                    string updateStock = "UPDATE Products SET Quantity = Quantity - @Qty WHERE Barcode = @Barcode";
                    using (SqliteCommand cmdUpdate = new SqliteCommand(updateStock, conn))
                    {
                        cmdUpdate.Parameters.AddWithValue("@Qty", qtySold);
                        cmdUpdate.Parameters.AddWithValue("@Barcode", txtSaleBarcode.Text);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    MessageBox.Show("تمت عملية البيع بنجاح!", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadProductsData(); LoadSalesData(); CalculateBusinessMetrics(); ClearPOSInputs();
                }
                catch (Exception ex) { MessageBox.Show("حدث خطأ: " + ex.Message); }
            }
        }

        private void BtnPrintInvoice_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument(); pd.PrintPage += new PrintPageEventHandler(PrintInvoicePage);
            PrintPreviewDialog pdd = new PrintPreviewDialog() { Document = pd }; pdd.ShowDialog();
        }

        private void PrintInvoicePage(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics; Font fontHeader = new Font("Arial", 14, FontStyle.Bold); Font fontBody = new Font("Arial", 11, FontStyle.Regular);
            float yPos = 20; g.DrawString("Temo Mobile Store", fontHeader, Brushes.Blue, 100, yPos); yPos += 30;
            g.DrawString("فاتورة مبيعات عميل", fontHeader, Brushes.Black, 115, yPos); yPos += 40;
            g.DrawString($"التاريخ والوقت: {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}", fontBody, Brushes.Black, 20, yPos); yPos += 30;
            g.DrawString("--------------------------------------------------", fontBody, Brushes.Black, 20, yPos); yPos += 20;

            if (dgvSales.Rows.Count > 0)
            {
                var latestRow = dgvSales.Rows[0];
                g.DrawString($"المنتج: {latestRow.Cells["المنتج"].Value}", fontBody, Brushes.Black, 20, yPos); yPos += 25;
                g.DrawString($"الكمية: {latestRow.Cells["الكمية المباعة"].Value}", fontBody, Brushes.Black, 20, yPos); yPos += 25;
                g.DrawString("--------------------------------------------------", fontBody, Brushes.Black, 20, yPos); yPos += 25;
                g.DrawString($"إجمالي الحساب: {latestRow.Cells["الإجمالي"].Value} ج.م", fontHeader, Brushes.Green, 20, yPos);
            }
            yPos += 40; g.DrawString("شكراً لتعاملكم معنا ك تيمو ستور!", fontBody, Brushes.Black, 80, yPos);
        }

        private void ClearPOSInputs()
        {
            txtSaleBarcode.Clear(); txtSaleName.Clear(); txtCustomerPrice.Clear(); txtSaleQty.Text = "1"; txtSaleTotal.Clear(); txtSaleBarcode.Focus();
        }

        private void LoadProductsData()
        {
            DataTable dt = new DataTable(); dt.Columns.AddRange(new DataColumn[] { new DataColumn("الباركود"), new DataColumn("اسم المنتج"), new DataColumn("سعر الشراء"), new DataColumn("سعر البيع"), new DataColumn("الكمية") });
            string query = "SELECT Barcode, ProductName, Price, SalePrice, Quantity FROM Products";
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    try { conn.Open(); using (SqliteDataReader reader = cmd.ExecuteReader()) { while (reader.Read()) dt.Rows.Add(reader["Barcode"], reader["ProductName"], reader["Price"], reader["SalePrice"], reader["Quantity"]); } dgvProducts.DataSource = dt; }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void LoadSalesData()
        {
            DataTable dt = new DataTable(); dt.Columns.AddRange(new DataColumn[] { new DataColumn("رقم البيع"), new DataColumn("المنتج"), new DataColumn("الكمية المباعة"), new DataColumn("الإجمالي"), new DataColumn("التاريخ والوقت ⏰") });
            DataTable dtReports = new DataTable(); dtReports.Columns.AddRange(new DataColumn[] { new DataColumn("رقم الحركة"), new DataColumn("المنتج"), new DataColumn("سعر الشراء"), new DataColumn("سعر البيع"), new DataColumn("الكمية"), new DataColumn("الربح الصافي"), new DataColumn("التاريخ والوقت ⏰") });

            string query = "SELECT SaleID, ProductName, CostPrice, Price, QuantitySold, Total, SaleDate FROM Sales ORDER BY SaleID DESC";
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqliteDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                dt.Rows.Add(reader["SaleID"], reader["ProductName"], reader["QuantitySold"], reader["Total"], reader["SaleDate"]);
                                decimal cost = Convert.ToDecimal(reader["CostPrice"]); decimal sell = Convert.ToDecimal(reader["Price"]); int qty = Convert.ToInt32(reader["QuantitySold"]);
                                dtReports.Rows.Add(reader["SaleID"], reader["ProductName"], cost, sell, qty, (sell - cost) * qty, reader["SaleDate"]);
                            }
                        }
                        dgvSales.DataSource = dt; dgvReports.DataSource = dtReports;
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvProducts.Rows[e.RowIndex];
                txtBarcode.Text = row.Cells["الباركود"].Value.ToString(); txtProductName.Text = row.Cells["اسم المنتج"].Value.ToString();
                txtCostPrice.Text = row.Cells["سعر الشراء"].Value.ToString(); txtSalePrice.Text = row.Cells["سعر البيع"].Value.ToString(); txtQuantity.Text = row.Cells["الكمية"].Value.ToString();
                txtBarcode.ReadOnly = true; btnSaveUpdate.Enabled = false;
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBarcode.Text) || string.IsNullOrEmpty(txtProductName.Text)) return;
            string query = "INSERT INTO Products (Barcode, ProductName, Price, SalePrice, Quantity) VALUES (@Barcode, @ProductName, @Price, @SalePrice, @Quantity)";
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Barcode", txtBarcode.Text); cmd.Parameters.AddWithValue("@ProductName", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@Price", Convert.ToDecimal(txtCostPrice.Text)); cmd.Parameters.AddWithValue("@SalePrice", Convert.ToDecimal(txtSalePrice.Text)); cmd.Parameters.AddWithValue("@Quantity", Convert.ToInt32(txtQuantity.Text));
                    try { conn.Open(); cmd.ExecuteNonQuery(); LoadProductsData(); ClearInputs(); MessageBox.Show("تم إضافة المنتج بنجاح!", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information); }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void btnEditMode_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBarcode.Text)) { MessageBox.Show("اختر منتجاً أولاً!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            btnSaveUpdate.Enabled = true;
        }

        private void btnSaveUpdate_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Products SET ProductName = @ProductName, Price = @Price, SalePrice = @SalePrice, Quantity = @Quantity WHERE Barcode = @Barcode";
            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                using (SqliteCommand cmd = new SqliteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Barcode", txtBarcode.Text); cmd.Parameters.AddWithValue("@ProductName", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@Price", Convert.ToDecimal(txtCostPrice.Text)); cmd.Parameters.AddWithValue("@SalePrice", Convert.ToDecimal(txtSalePrice.Text)); cmd.Parameters.AddWithValue("@Quantity", Convert.ToInt32(txtQuantity.Text));
                    try { conn.Open(); cmd.ExecuteNonQuery(); LoadProductsData(); btnSaveUpdate.Enabled = false; MessageBox.Show("تم تعديل المنتج!", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information); }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void ClearInputs() { txtBarcode.ReadOnly = false; txtBarcode.Clear(); txtProductName.Clear(); txtCostPrice.Clear(); txtSalePrice.Clear(); txtQuantity.Clear(); btnSaveUpdate.Enabled = false; txtBarcode.Focus(); }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBarcode.Text)) return;
            if (MessageBox.Show("حذف المنتج؟", "تحذير", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string query = "DELETE FROM Products WHERE Barcode = @Barcode";
                using (SqliteConnection conn = new SqliteConnection(connectionString))
                {
                    using (SqliteCommand cmd = new SqliteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Barcode", txtBarcode.Text);
                        try { conn.Open(); cmd.ExecuteNonQuery(); LoadProductsData(); ClearInputs(); } catch (Exception ex) { MessageBox.Show(ex.Message); }
                    }
                }
            }
        }
    }
}